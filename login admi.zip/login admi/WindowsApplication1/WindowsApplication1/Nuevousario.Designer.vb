﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Nuevousario
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Password = New System.Windows.Forms.TextBox()
        Me.Answers = New System.Windows.Forms.TextBox()
        Me.textQuestion = New System.Windows.Forms.TextBox()
        Me.PassRect = New System.Windows.Forms.TextBox()
        Me.UserdID = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Password
        '
        Me.Password.Location = New System.Drawing.Point(217, 102)
        Me.Password.Name = "Password"
        Me.Password.Size = New System.Drawing.Size(100, 20)
        Me.Password.TabIndex = 11
        '
        'Answers
        '
        Me.Answers.Location = New System.Drawing.Point(217, 210)
        Me.Answers.Name = "Answers"
        Me.Answers.Size = New System.Drawing.Size(100, 20)
        Me.Answers.TabIndex = 10
        '
        'textQuestion
        '
        Me.textQuestion.Location = New System.Drawing.Point(217, 174)
        Me.textQuestion.Name = "textQuestion"
        Me.textQuestion.Size = New System.Drawing.Size(100, 20)
        Me.textQuestion.TabIndex = 9
        '
        'PassRect
        '
        Me.PassRect.Location = New System.Drawing.Point(217, 130)
        Me.PassRect.Name = "PassRect"
        Me.PassRect.Size = New System.Drawing.Size(100, 20)
        Me.PassRect.TabIndex = 8
        '
        'UserdID
        '
        Me.UserdID.Location = New System.Drawing.Point(217, 76)
        Me.UserdID.Name = "UserdID"
        Me.UserdID.Size = New System.Drawing.Size(100, 20)
        Me.UserdID.TabIndex = 7
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(264, 260)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(119, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "UserID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(119, 105)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Password"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(119, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Reypte_password"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(120, 177)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 16
        Me.Label4.Text = "Quetion"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(119, 217)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(42, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Answer"
        '
        'Nuevousario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(525, 354)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Password)
        Me.Controls.Add(Me.Answers)
        Me.Controls.Add(Me.textQuestion)
        Me.Controls.Add(Me.PassRect)
        Me.Controls.Add(Me.UserdID)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Nuevousario"
        Me.Text = "Nuevousario"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Password As TextBox
    Friend WithEvents Answers As TextBox
    Friend WithEvents textQuestion As TextBox
    Friend WithEvents PassRect As TextBox
    Friend WithEvents UserdID As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
End Class
