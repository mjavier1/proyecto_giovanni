﻿Imports MySql.Data.MySqlClient

Public Class Nuevousario
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If UserdID.Text = "" Or Password.Text = " " Or textQuestion.Text = "" Or Answers.Text = "" Then
            MsgBox("Pefect 100%")

        ElseIf Password.Text <> PassRect.Text Then ''
            MsgBox("Escriba bien password")
        Else
            Dim ServerMysql As String = "Server=localhost;User Id=mj; Password=datasql; Database=Users"
            Dim conn As New MySqlConnection(ServerMysql)
            Dim comand As New MySqlCommand


            conn.Open()
            comand.Connection = conn
            comand.CommandText = "insert into login(userid,password,pregunta,respueta) values ('" & UserdID.Text & "','" & Password.Text & ",'" & textQuestion.Text & "','" & ",'" & Answers.Text & "')"
            comand.ExecuteNonQuery()
            MsgBox("Sucessfully Regitrado")
            UserdID.Text = ""
            PassRect.Text = ""
            textQuestion.Text = ""
            Answers.Text = ""
            conn.Close()

        End If





    End Sub
End Class