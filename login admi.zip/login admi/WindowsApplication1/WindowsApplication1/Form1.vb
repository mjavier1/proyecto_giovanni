﻿Imports MySql.Data.MySqlClient
Public Class Form1
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim ServerMysql As String = "Server=localhost;User Id=mj; Password=datasql; Database=Users"
        Dim conn As New MySqlConnection(ServerMysql)
        Dim comand As New MySqlCommand
        Dim dr As MySqlDataReader

        conn.Open()
        comand.Connection = conn

        comand.CommandText = "select userid,password from login where userid ='" & TextBox1.Text & "'and password ='" & TextBox2.Text & "'"
        dr = comand.ExecuteReader
        If dr.HasRows Then
            Me.Hide()
            Sec.Show()
        Else
            MsgBox("Userid or password does not matched")

        End If



    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Nuevousario.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        olvidar.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        change.Show()
    End Sub
End Class
